export class User {

id: number;
firstName: string;
lastName: string;
username: string;
age: number;
salary: number;
}
