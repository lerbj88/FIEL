import { Component, OnInit , Inject, ViewChild} from '@angular/core';
import {Router} from "@angular/router";
import {User} from "../../model/user.model";
import {ApiService} from "../../service/api.service";
import {DataSource} from '@angular/cdk/collections';
import {MatTableDataSource, MatSort, MatPaginator } from '@angular/material';



@Component({
  selector: 'app-list-user',
  templateUrl: './list-user.component.html',
  styleUrls: ['./list-user.component.css']
})




export class ListUserComponent implements OnInit {

  constructor(private router: Router, private apiService: ApiService) { 
    this.apiService.getUsers().subscribe(data =>{
      this.dataSource = new MatTableDataSource(data.result);
      this.dataSource.paginator = this.paginator;  
    this.dataSource.sort = this.sort;  
    });
  }
  users: User[];
  displayedColumns: string[] = ['id', 'firstName', 'lastName', 'username', 'salary', 'age'];
  dataSource : MatTableDataSource<User>;  
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;  
  @ViewChild(MatSort, {static: true}) sort: MatSort;  

  ngOnInit() {
    if(!window.localStorage.getItem('token')) {
      this.router.navigate(['login']);
      return;
    }
    this.apiService.getUsers()
      .subscribe( data => {
        this.users = data.result;
      });
      this.dataSource.paginator = this.paginator;  
      this.dataSource.sort = this.sort;  
  }


  applyFilter(filterValue: string) {  
    this.dataSource.filter = filterValue.trim().toLowerCase();  
  
    if (this.dataSource.paginator) {  
      this.dataSource.paginator.firstPage();  
    }  
  }  

  deleteUser(user: User): void {
    this.apiService.deleteUser(user.id)
      .subscribe( data => {
        this.users = this.users.filter(u => u !== user);
      })
  };

  editUser(user: User): void {
    window.localStorage.removeItem("editUserId");
    window.localStorage.setItem("editUserId", user.id.toString());
    this.router.navigate(['edit-user']);
  };

  addUser(): void {
    this.router.navigate(['add-user']);
  };




  }

  

  